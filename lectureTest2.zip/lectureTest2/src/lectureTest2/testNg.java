
//AS2015412
//H. A. D. G. JANITH
package lectureTest2;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.BeforeClass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class testNg {
	WebDriver driver;
	
	
	
	
	
	@Test(priority = 0)
	public void testMethod1() {
		String url = "https://www.ebay.com/";
		//(3) Get the page URL and verify if it is the correct page that is open
			String actualUrl = driver.getCurrentUrl();//Storing URL in String variable
			if (actualUrl.equals(url)){
				System.out.println("Verification Successful - The correct Url is opened.");
				}else{
				System.out.println("Verification Failed - An incorrect Url is opened.");
				//In case of Fail, you like to print the actual and expected URL for the record purpose

				System.out.println("Actual URL is : " + actualUrl);
				System.out.println("Expected URL is : " + url);
				}
		
		
	}

	@Test(priority = 1)
	public void testMethod2() {
		//(4)Select the category 'Books' from all categories dropdown list
			Select label = new Select(driver.findElement(By.id("gh-cat")));
			label.selectByIndex(4);// Select the category books
			
			
			//(5)Click on 'Search' button
			driver.findElement(By.id("gh-btn")).click();
		
	}


	@Test(priority = 2)
	public void testMethod3() {

		//(6)Verify redirected page Title and print the Title in eclipse console
		String title = "Books for sale | eBay";//Storing the predefined title in the String variable			
		String actualTitle = driver.getTitle();//Storing current title in String variable
		if (actualTitle.equals(title)){
			System.out.println("Verification Successful - The correct title page is opened.");
			System.out.println("Title of the page is : " + actualTitle);
		}else{
			System.out.println("Verification Failed - An incorrect title page is opened.");
			//Only in case of Fail
			System.out.println("Actual title is : " + actualTitle);//what you go
			System.out.println("Expected title is : " + title);//what you want to go
			}
	}
	@Test(priority = 3)
	public void testMethod4() {
		//(7)Get the title length and print in eclipse console
			int titleLength = driver.getTitle().length();//Storing Title length in the  variable
			System.out.println("Length of the title is : "+ titleLength);
			System.out.println(" ");

	}
	@Test(priority = 4)
	public void testMethod5() {

		//(8)In the 'Search for anything' text field type "Harry Potter"
		driver.findElement(By.id("gh-ac")).sendKeys("Harry Potter");
		
		
		//(9)Click on Search button
		driver.findElement(By.id("gh-btn")).click();
		
		
	}
	@Test(priority = 5)
	public void testMethod6() {
		//(10)Select a book Harry Potter : The Complete Collection 8 Books in PDF and EPUB Format
			driver.findElement(By.linkText("Harry Potter Complete Collection (Books 1 to 8) by JK Rowling ΕBook (PDF )")).click();
	}
	@Test(priority = 6)
	public void testMethod7() {
		//(11)Verify selected details in refine page[Name, Price]
		
			String bookTitle = "Harry Potter Complete Collection (Books 1 to 8) by JK Rowling ?Book (PDF )";//Storing the predefined book title in the String variable			
			String price = "US $1.00";
			
			String actualBookTitle = driver.findElement(By.xpath(".//*[@id='itemTitle']")).getText();//Storing current book title in String variable
			String actualPrice = driver.findElement(By.xpath(".//*[@id='prcIsum']")).getText();//Storing current book price in String variable
			
			
			if (actualBookTitle.equals(bookTitle)){
				System.out.println("Verification Successful - The correct book found");
				System.out.println("Title of the Book is : " + actualBookTitle);
			}else{
				System.out.println("Verification Failed - An incorrect Book found");
				//Only in case of Fail
				System.out.println("Actual book that got is : " + actualBookTitle);//book you got
				System.out.println("Expected book to get is : " + bookTitle);//wanted book
				}
			
			if(actualPrice.equals(price)) {
				System.out.println("Verification Successful - The correct book price found");
			}else{
				System.out.println("Verification Failed - An incorrect book price is got.");
				//Only in case of Fail
				System.out.println("Actual price is : " + actualPrice);//wanted price
				System.out.println("Expected Price is : " + price);//price you got
				}
			//(12)Print book name and price in eclipse console
			System.out.println("Book Title : " + actualBookTitle);//book
			System.out.println("Book price : " + actualPrice);//price
	}
	@Test(priority = 7)
	public void testMethod8() {
		//(13)Verify the condition of the book and print in eclipse console
		
			String expectedCondition =("Brand New");
			String condition = driver.findElement(By.xpath(".//*[@id='vi-itm-cond']")).getText();
			
			if(expectedCondition.equals(condition)) {
				System.out.println("Verification Successful - The book is in correct condition");
			}else {
				System.out.println("Actual condition of the book  : " + condition);//book condition you got
				System.out.println("Expected condition of the book: " + expectedCondition);//wanted book condition
			}
		
		
	}

	@Test(priority = 8)
	public void testMethod9() {
		//(14)Verify the shipping is Free or not and print in the eclipse console.
			String expectedShipping = "FREE";
			String shipping = driver.findElement(By.xpath(".//*[@id='fshippingCost']")).getText();
			
			if(expectedShipping.equals(shipping)) {
				System.out.println("Verification Successful - Shipping is free");
			}else {
				System.out.println("Shipping is not free. It is : " + shipping);//Shipping details
			}
		
	}

	@Test(priority = 9)
	public void testMethod10() {
		//(15)Click on 'add to cart' button
			driver.findElement(By.id("isCartBtn_btn")).click();
			
		
	}

	@Test(priority = 10)
	public void testMethod11() {
		String price = "US $1.00";
		
		//(16)Select 'Qty' as 2 from the dropdown menu
			Select qty = new Select(driver.findElement(By.xpath(".//*[@data-test-id='qty-dropdown']")));
			qty.selectByVisibleText("2");;// Select the quantity
			
			
			
			//(17)Verify the No of items added,after the quantity change;
			String newQty = "2";
			
			  String actualQty = qty.getFirstSelectedOption().getText();//Storing current book quantity in String variable
			  System.out.println("    ");
			 
			
			if(actualQty.equals(newQty)) {
				System.out.println("Verification Successful - The correct book quantity");
			}else{
				System.out.println("Verification Failed - An incorrect book quantity");
				//Only in case of Fail
				System.out.println("Actual quantity is : " + actualQty);//wanted quantity
				System.out.println("Expected quantity is : " + newQty);//quantity you got
				}
		
			int newQty1 = Integer.parseInt(newQty);//convert string to integer

			int price1 = Integer.valueOf(price.substring(4,5));//convert string to integer
			
			
			int totalPrice = price1*newQty1;
			String totalPrice2 = "US $"+ totalPrice +".00";
			
			
			String newActualPrice ="US $2.00";

			//double newActualPrice1 = Double.valueOf(newActualPrice.substring(4));
			
			if(totalPrice2.equals(newActualPrice)){
				System.out.println("Price change was verified");
				System.out.println("Price :"+totalPrice2);
				
			}
			
			else{
				System.out.println("Price change was not verified");
				System.out.println(newActualPrice);
				System.out.println(totalPrice2);
			}
		
	}

	@Test(priority = 11)
	public void testMethod12() {
		//(19)Click on 'sign in' link
			driver.findElement(By.xpath("//a[@title='Sign In']")).click();
	}

	@Test(priority = 12)
	public void testMethod13() {
		//(20)Click on 'Create an Account' link
			driver.findElement(By.xpath("//a[@id='CreateAnAccount']")).click();
			
	}

	@Test(priority = 13)
	  @Parameters({"fName","lName","eMail","password"})
	  public void testMethod14(String fName, String lName, String eMail, String password) {
		  
			
			driver.findElement(By.name("firstname")).sendKeys(fName);
			driver.findElement(By.name("lastname")).sendKeys(lName);
			driver.findElement(By.name("email")).sendKeys(eMail);
			driver.findElement(By.name("PASSWORD")).sendKeys(password);		
			WebElement oCheckBox = driver.findElement(By.name("checkbox-default"));
			oCheckBox.click();
			
			
	  }
	
	
	
	
	@BeforeClass
	public void beforeClass() {
		String exePath = "E:\\Tests selenium\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		driver = new ChromeDriver();
		String url = "https://www.ebay.com/";//Storing the Application Url in the String variable

		driver.get(url);
	}
	@AfterClass
	public void afterClass() {
		driver.close();
	}

}
