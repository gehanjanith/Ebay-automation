
//AS2015412
//H. A. D. G. JANITH
package lectureTest2;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.yaml.snakeyaml.events.Event.ID;

import com.gargoylesoftware.htmlunit.WebAssert;
import com.gargoylesoftware.htmlunit.javascript.host.html.Option;

public class testEbay {
	
	public static void main(String[] args) throws java.lang.NumberFormatException{
	
	String exePath = "E:\\Tests selenium\\chromedriver_win32\\chromedriver.exe";
	System.setProperty("webdriver.chrome.driver", exePath);

	//(1) Launch a Chrome Browser
	WebDriver driver = new ChromeDriver();//Create a new instance of the Chrome driver
  String url = "https://www.ebay.com/";//Storing the Application Url in the String variable

	
	//(2) Navigate to URL "ebay.com"
	driver.get(url);//Launch the ToolsQA WebSite
	
	
	//(3) Get the page URL and verify if it is the correct page that is open
	String actualUrl = driver.getCurrentUrl();//Storing URL in String variable
	if (actualUrl.equals(url)){
		System.out.println("Verification Successful - The correct Url is opened.");
		}else{
		System.out.println("Verification Failed - An incorrect Url is opened.");
		//In case of Fail, you like to print the actual and expected URL for the record purpose

		System.out.println("Actual URL is : " + actualUrl);
		System.out.println("Expected URL is : " + url);
		}
	System.out.println(" ");
	
	
	
	//(4)Select the category 'Books' from all categories dropdown list
	Select label = new Select(driver.findElement(By.id("gh-cat")));
	label.selectByIndex(4);// Select the category books
	
	
	//(5)Click on 'Search' button
	driver.findElement(By.id("gh-btn")).click();
	
	
	//(6)Verify redirected page Title and print the Title in eclipse console
	String title = "Books for sale | eBay";//Storing the predefined title in the String variable			
	String actualTitle = driver.getTitle();//Storing current title in String variable
	if (actualTitle.equals(title)){
		System.out.println("Verification Successful - The correct title page is opened.");
		System.out.println("Title of the page is : " + actualTitle);
	}else{
		System.out.println("Verification Failed - An incorrect title page is opened.");
		//Only in case of Fail
		System.out.println("Actual title is : " + actualTitle);//what you go
		System.out.println("Expected title is : " + title);//what you want to go
		}
	System.out.println(" ");
	
	
	//(7)Get the title length and print in eclipse console
	int titleLength = driver.getTitle().length();//Storing Title length in the  variable
	System.out.println("Length of the title is : "+ titleLength);
	System.out.println(" ");
	
	
	
	//(8)In the 'Search for anything' text field type "Harry Potter"
	driver.findElement(By.id("gh-ac")).sendKeys("Harry Potter");
	
	
	//(9)Click on Search button
	driver.findElement(By.id("gh-btn")).click();
	
	
	//(10)Select a book Harry Potter : The Complete Collection 8 Books in PDF and EPUB Format
	driver.findElement(By.linkText("Harry Potter Complete Collection (Books 1 to 8) by JK Rowling ΕBook (PDF )")).click();
	
	
	
	
	
	//(11)Verify selected details in refine page[Name, Price]
	
	String bookTitle = "Harry Potter Complete Collection (Books 1 to 8) by JK Rowling ΕBook (PDF )";//Storing the predefined book title in the String variable			
	String price = "US $1.00";
	
	String actualBookTitle = driver.findElement(By.xpath(".//*[@id='itemTitle']")).getText();//Storing current book title in String variable
	String actualPrice = driver.findElement(By.xpath(".//*[@id='prcIsum']")).getText();//Storing current book price in String variable
	
	
	if (actualBookTitle.equals(bookTitle)){
		System.out.println("Verification Successful - The correct book found");
		System.out.println("Title of the Book is : " + actualBookTitle);
	}else{
		System.out.println("Verification Failed - An incorrect Book found");
		//Only in case of Fail
		System.out.println("Actual book that got is : " + actualBookTitle);//book you got
		System.out.println("Expected book to get is : " + bookTitle);//wanted book
		}
	
	if(actualPrice.equals(price)) {
		System.out.println("Verification Successful - The correct book price found");
	}else{
		System.out.println("Verification Failed - An incorrect book price is got.");
		//Only in case of Fail
		System.out.println("Actual price is : " + actualPrice);//wanted price
		System.out.println("Expected Price is : " + price);//price you got
		}
	System.out.println(" ");
	
	
	
	//(12)Print book name and price in eclipse console
	System.out.println("Book Title : " + actualBookTitle);//book
	System.out.println("Book price : " + actualPrice);//price
	System.out.println("  ");
	
	
	
	//(13)Verify the condition of the book and print in eclipse console
	
	String expectedCondition =("Brand New");
	String condition = driver.findElement(By.xpath(".//*[@id='vi-itm-cond']")).getText();
	
	if(expectedCondition.equals(condition)) {
		System.out.println("Verification Successful - The book is in correct condition");
	}else {
		System.out.println("Actual condition of the book  : " + condition);//book condition you got
		System.out.println("Expected condition of the book: " + expectedCondition);//wanted book condition
	}
	System.out.println("   ");
	
	//(14)Verify the shipping is Free or not and print in the eclipse console.
	String expectedShipping = "FREE";
	String shipping = driver.findElement(By.xpath(".//*[@id='fshippingCost']")).getText();
	
	if(expectedShipping.equals(shipping)) {
		System.out.println("Verification Successful - Shipping is free");
	}else {
		System.out.println("Shipping is not free. It is : " + shipping);//Shipping details
	}
	System.out.println(" ");
	
	
	
	//(15)Click on 'add to cart' button
	driver.findElement(By.id("isCartBtn_btn")).click();
	
	
	
	//(16)Select 'Qty' as 2 from the dropdown menu
	Select qty = new Select(driver.findElement(By.xpath(".//*[@data-test-id='qty-dropdown']")));
	qty.selectByVisibleText("2");;// Select the quantity
	
	
	
	//(17)Verify the No of items added,after the quantity change;
	String newQty = "2";
	
	  String actualQty = qty.getFirstSelectedOption().getText();//Storing current book quantity in String variable
	  System.out.println("    ");
	 
	
	if(actualQty.equals(newQty)) {
		System.out.println("Verification Successful - The correct book quantity");
	}else{
		System.out.println("Verification Failed - An incorrect book quantity");
		//Only in case of Fail
		System.out.println("Actual quantity is : " + actualQty);//wanted quantity
		System.out.println("Expected quantity is : " + newQty);//quantity you got
		}
	System.out.println(" ");
	
	int newQty1 = Integer.parseInt(newQty);//convert string to integer

	int price1 = Integer.valueOf(price.substring(4,5));//convert string to integer
	
	
	int totalPrice = price1*newQty1;
	String totalPrice2 = "US $"+ totalPrice +".00";
	
	
	String newActualPrice ="US $2.00";
		System.out.println(newActualPrice);

	//double newActualPrice1 = Double.valueOf(newActualPrice.substring(4));
	
	if(totalPrice2.equals(newActualPrice)){
		System.out.println("Price change was verified");
		System.out.println("Price :"+totalPrice2);
		
	}
	
	else{
		System.out.println("Price change was not verified");	
	}
	System.out.println(" ");
	
	
	//(19)Click on 'sign in' link
	driver.findElement(By.xpath("//a[@title='Sign In']")).click();
	
	
	//(20)Click on 'Create an Account' link
	driver.findElement(By.xpath("//a[@id='CreateAnAccount']")).click();
	
	
	//(21)Add all required details in text fields
	driver.findElement(By.name("firstname")).sendKeys("Gehan");
	driver.findElement(By.name("lastname")).sendKeys("Hettiarchchi");
	driver.findElement(By.name("email")).sendKeys("gehanjanith@gmail.com");
	driver.findElement(By.name("PASSWORD")).sendKeys("admingehan");		
	WebElement oCheckBox = driver.findElement(By.name("checkbox-default"));
		oCheckBox.click();
	
	
	//(22)Closing browser
	 driver.close();
}
}